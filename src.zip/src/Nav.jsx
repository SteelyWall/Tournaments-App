import * as React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { NavigationContainer } from "@react-navigation/native";
import { InicioVista } from "./vistas/inicio.vista";
import { Main } from "./vistas/main.vista";
import { HomeVista } from "./vistas/home.vista";
import { RegistroVista } from "./vistas/registro.vista";
import { AddTorneo } from "./vistas/addtorneo.vista";
import { auth } from "./componentes/firebase.config";
import { useAuth } from "./Hooks/useAuth";
import { AddEquipo } from "./vistas/addequipo.vista";
import { AddJugador } from "./vistas/addjugador.vista";
import { Perfil } from "./vistas/perfil.vista";

// diferentes pantallas
// se crea una constante llamada nav, donde estaran todas las vistas de la App, con un nombre y el componente

export const Nav = () => {
  const { Navigator, Screen, Group } = createNativeStackNavigator();
  // en la constante opciones sirve para decirle que el header no se muestre,
  // ademas que tenga una animacion que en este momento es la default,
  const opciones = {
    headerShown: false,
    animation: "default",
  };
  const { authStatus } = useAuth();
  return (
    <NavigationContainer>
      <Navigator screenOptions={opciones}>
        {authStatus.loged ? (
          <Group>
            <Screen name="home" component={HomeVista} />
            <Screen name="addTorneo" component={AddTorneo} />
            <Screen name="main" component={Main} />
            <Screen name="addJugador" component={AddJugador} />
            <Screen name="perfil" component={Perfil} />
          </Group>
        ) : (
          <Group>
            <Screen name="inicio" component={InicioVista} />
            <Screen name="registro" component={RegistroVista} />
          </Group>
        )}
      </Navigator>
    </NavigationContainer>
  );};
