import { useContext } from "react";
import { authContex } from "../contexto/auth.context";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut
} from "firebase/auth";
import { auth } from "../componentes/firebase.config";

export const useAuth = () => {
  const { authStatus, setauthStatus, appLoading, setappLoading } =
    useContext(authContex);
  async function registro(email, contra) {
    try {
      const datos = await createUserWithEmailAndPassword(auth, email, contra);
      if (datos.user.email) {
        const user = {
          loged: true,
          user: {
            email: datos.user.email,
          },
        };
        setauthStatus(user);
        return {
          ...user,
          mensaje: `iniciado sesion con ${datos.user.email}`,
        };
      }
      return {
        user: null,
        loged: false,
        mensaje: `error`,
      };
    } catch (error) {
      return {
        user: null,
        loged: false,
        mensaje: `error`,
      };
    }
  }

  async function cerrarSesion() {
    try {
        await signOut(auth);
        setauthStatus({
            loged: false,
            user: null,
        });
    } catch (error) {
        console.log(error.message);
    }
}

  async function iniciarSesion(email, contra) {
    try {
      const datos = await signInWithEmailAndPassword(auth, email, contra);
      console.log(datos)
      if (datos.user.email) {
        const user = {
          loged: true,
          user: {
            email: datos.user.email,
          },
        };
        setauthStatus(user)
        return {
          ...user,
          mensaje: `Se ha iniciado sesión`,
        }
      }
      return {
        user: null,
        loged: false,
        mensaje: `error`,
      };
    } catch (error) {
      console.log(error)
      return {
        user: null,
        loged: false,
        mensaje: `error`,
      };
    }
  }
  return {
    cerrarSesion,
    iniciarSesion,
    registro,
    authStatus,
    setauthStatus,
    appLoading,
    setappLoading,
  };
};

