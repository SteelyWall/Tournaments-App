import { createContext, useState } from "react";

export const authContex = createContext();

export const AuthProvider = ({ children }) => {
    const Default = {
        loged: false,
        user: null,
    };
    const [authStatus, setauthStatus] = useState(Default);
    const [appLoading, setappLoading] = useState(true);
    return <authContex.Provider value={{authStatus, setauthStatus, appLoading, setappLoading}}>{children}</authContex.Provider>;
};
