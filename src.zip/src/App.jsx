import { Nav } from "./Nav"
import { AuthProvider } from "./contexto/auth.context"

export const App = () => {
  return <AuthProvider> 
            <Nav></Nav>
          </AuthProvider>
}

