import { addDoc, collection } from "firebase/firestore";
import React, { useState } from "react";
import {
  Pressable,
  StyleSheet,
  Text,
  ImageBackground,
  View,
  _Text,
  TextInput,
  ScrollView,
} from "react-native";
import { BD } from "../componentes/firebase.config";



export const AddTorneo = ({ navigation }) => {
  //useState para realizar el registro del torneo

  const [Nombre, setNombre] = useState("");
  const [NumEquipos, setNumEquipos] = useState("");
  const [Rondas, setRondas] = useState("");
  const [Equipos, setEquipos] = useState([]);
  const [ids, setids] = useState(0);
//imagen de fondo
  const Image = { uri: "https://i.ibb.co/cYLP9z9/prueba.png>" };
  const [Duelos, setDuelos] = useState([]);

  // funcion añadir equipo
  function addEquipo() {
    const id = ids;
    setids(id + 1);
    setEquipos([
      ...Equipos,
      {
        nombre: "",
        id,
      },
    ]);
  }
            
  function addDuelo() {
    const id = ids;
    setids(id + 1);
    setDuelos([
      ...Duelos,
      {
        equipo1: "",
        equipo2: "",
        goles1: "",
        goles2: "",
        id,
      },
    ]);
  }
// funcion eliminar del boton que existe en los textInputs (sirve para eliminar el input)
  function eliminar(id) {
    const equipos = Equipos.filter((e) => e.id !== id);
    setEquipos(equipos);
  }
//funcion asincrona enviar, esta lleva los datos de los inputs a la base de datos alojada en Firebase
  async function enviar() {
    const torneo = {
      nombre: Nombre,
      numEquipo: NumEquipos,
      rondas: Rondas,
      equipos: Equipos,
    };
    console.log(torneo);
    const data = await addDoc(collection(BD, "torneos"), torneo);
    console.log(data);

  }
  return (
    <View style={style.view}>
      <ImageBackground source={Image} resizeMode="cover" style={style.image}>
        <View>
          <TextInput
            style={style.input}
            placeholderTextColor={"gray"}
            placeholder={"Escriba Nombre del Torneo"}
            value={Nombre}
            onChangeText={setNombre}
          />
        </View>
        <View style={style.contenedor}>
          <View>
            <Text style={style.label}>Numero de Equipos</Text>
            <TextInput
              style={style.input2}
              placeholderTextColor={"black"}
              value={NumEquipos}
              keyboardType={"numeric"}
              onChangeText={setNumEquipos}
            />
          </View>
          <View>
            <Text style={style.label}>Rondas</Text>
            <TextInput
              style={style.input2}
              placeholderTextColor={"black"}
              value={Rondas}
              keyboardType={"numeric"}
              onChangeText={setRondas}
            />
          </View>
        </View>
        <Text style={style.label2}>Añadir Equipos</Text>
        <ScrollView
          style={{
            maxHeight: 300,
            paddingHorizontal: 24,
            width: "100%",
            top: 50,
            
          }}
        >
          {Equipos.map((equipo, i) => (
            <View style={style.input3}>
              <TextInput
                style={{             
                  width: "80%",
                }}
                placeholderTextColor={"black"}
                value={Equipos[i].nombre}
                onChangeText={(text) => {
                  const equipos = Equipos.filter((e) => e.id !== equipo.id);
                  setEquipos([
                    ...equipos,
                    {
                      nombre: text,
                      id: equipo.id,
                    },        
                  ]);
                }}
              />
              <Pressable
                onPress={() => eliminar(equipo.id)}
                style={style.btnagg2}
              >
                <Text style={style.txt3}>Eliminar</Text>
              </Pressable>
            </View>
          ))}
        </ScrollView>
        <View style={style.btnz}>
          <Pressable onPress={addEquipo} style={style.btnagg3}>
            <Text style={style.txt3}>Añadir Equipos</Text>
          </Pressable>
        </View>
        <Pressable onPress={enviar} style={style.btnagg}>
          <Text style={style.txt3}>CREAR NUEVO TORNEO</Text>
        </Pressable>
      </ImageBackground>
    </View>
  );
};


//ESTILOS
const style = StyleSheet.create({
  btnz:{
    top:60,
    alignItems:"center",
  },
  input3: {
    borderRadius:7,
    backgroundColor: "white",
    color: "black",
    marginBottom: 10,
    height: 40,
    flexDirection: "row",
    alignItems: "center",
  },
  txt2: {
    textAlign: "center",
    fontSize: 15,
    color: "white",
    width: 284,
    height: 34,
    left: 0,
    top: 200,
  },
  txt3: {
    color: "white",
    textAlign: "center",
  },
  txt4: {
    color: "white",
    textAlign: "center",
    top: 400,
  },
  view: {
    flex: 1,
  },
  btnagg: {
    backgroundColor: "#008f39",
    padding: 10,
    paddingTop: 10,
    marginLeft: 20,
    marginRight: 20,
    width: 315,
    height: 39,
    left: 23,
    top: 80,
    borderRadius: 7,
  },
  btnagg2: {
    backgroundColor: "#008f39",
    paddingHorizontal: 7,
    height: "70%",
    borderRadius: 7,
    paddingTop:3,
  },
  btnagg3: {
    backgroundColor: "#008f39",
    padding: 10,
    width: 200,
    height: 39,
    borderRadius: 10,
    alignItems: "center",
  },
  image: {
    flex: 1,
  },
  input: {
    backgroundColor: "white",
    color: "black",
    marginLeft: 20,
    marginRight: 20,
    marginBottom: 20,
    paddingTop: 1,
    paddingBottom: 10,
    borderRadius: 10,
    top: 30,
  },
  label: {
    marginHorizontal: 5,
    marginBottom: 10,
    fontSize: 15,
    color: "#fff",
    left: 20,
  },
  label2: {
    marginHorizontal: 5,
    marginBottom: 10,
    fontSize: 20,
    color: "#fff",
    left: 20,
    top: 30,
  },
  contenedor: {
    top: 30,
  },
  input2: {
    backgroundColor: "white",
    color: "red",
    marginLeft: 20,
    marginRight: 300,
    marginBottom: 15,
    paddingTop: 1,
    paddingBottom: 1,
    borderRadius: 10,
  },
});
