import React, { useState } from "react";
import {
  Pressable,
  StyleSheet,
  Text,
  ImageBackground,
  View,
  _Text,
  TextInput,
} from "react-native";
import { useAuth } from "../Hooks/useAuth";

export const InicioVista = ({ navigation }) => {
  const Image = { uri: "https://i.ibb.co/cYLP9z9/prueba.png>" };

    return(
        <View>
            <Text>Estadisticas</Text>
        </View>
    )
}
