import React, { useState } from "react";
import {
  Pressable,
  StyleSheet,
  Text,
  ImageBackground,
  View,
  _Text,
  TextInput,
} from "react-native";

export const AddEquipo = ({ navigation }) => {
  const Image = { uri: "https://i.ibb.co/cYLP9z9/prueba.png>" };

  return (
    <View>

        <View>
          <Text>Añadir Equipo</Text>
          <Text>Equipo 1</Text>
        </View>
        <Pressable> 
          <Text>AGREGAR</Text>
        </Pressable>
        <Pressable> 
          <Text>CONTINUAR</Text>
        </Pressable>
    </View>
  );
};

