import React, { useState } from "react";
import {
  Pressable,
  StyleSheet,
  Text,
  ImageBackground,
  View,
  _Text,
  TextInput,
} from "react-native";

export const HomeVista = ({ navigation }) => {
  const Image = { uri: "https://i.ibb.co/cYLP9z9/prueba.png>" };
  const [Nombre, setNombre] = useState("");

  return (
    <View style={style.modal}>
      <ImageBackground source={Image} resizeMode="cover" style={style.image}>
        <Text style={style.txt}>Torneos</Text>
        <View>
          <TextInput
            style={style.input}
            placeholderTextColor={"gray"}
            placeholder={"Escriba Nombre del Torneo"}
            value={Nombre}
            onChangeText={setNombre}
          />
        </View>
        <Pressable
          onPress={() => navigation.navigate("addTorneo")}
          style={style.btnagg}
        >
          <Text style={style.txt3}>CREAR NUEVO TORNEO</Text>
        </Pressable>

        {/* <Pressable onPress={() => navigation.navigate('perfil')} style={style.btnagg}>
          <Text style={style.txt3}>TEST</Text>
        </Pressable> */}

      </ImageBackground>
    </View>
  );
};

const style = StyleSheet.create({
  modal: {
    flex: 1,
  },
  txt: {
    color: "#fff",
    fontSize: 25,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 30,
  },
  label: {
    marginHorizontal: 5,
    marginBottom: 5,
    fontSize: 15,
    color: "#fff",
  },
  input: {
    backgroundColor: "white",
    color: "red",
    marginLeft: 20,
    marginRight: 20,
    marginBottom: 15,
    paddingTop: 1,
    paddingBottom: 1,
    borderRadius: 10,
  },
  input2: {
    backgroundColor: "white",
    color: "red",
    marginLeft: 20,
    marginRight: 300,
    marginBottom: 15,
    paddingTop: 1,
    paddingBottom: 1,
    borderRadius: 10,
  },
  image: {
    flex: 1,
  },
  btnagg: {
    backgroundColor: "#008f39",
    padding: 10,
    paddingTop: 12,
    marginLeft: 20,
    marginRight: 20,
    width: 315,
    height: 50,
    left: 23,
    top: 300,
    borderRadius: 10,
  },
  txt3: {
    fontSize: 17,
    color: "white",
    textAlign: "center",
  },
});
