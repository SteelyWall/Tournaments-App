import React, { useState } from "react";
import {
  Pressable,
  StyleSheet,
  Text,
  ImageBackground,
  View,
  _Text,
  TextInput,
} from "react-native";

export const Main = ({ navigation }) => {
    return (
        <Text>HOLA MUNDO</Text>
    )
}