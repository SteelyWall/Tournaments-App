import React, { useState } from "react";
import {
  Pressable,
  StyleSheet,
  Text,
  ImageBackground,
  View,
  _Text,
  TextInput,
} from "react-native";

export const HomeVista = ({ navigation }) => {
  return <View></View>;
};
