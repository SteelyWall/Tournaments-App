// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import {getAuth} from "firebase/auth";
import {getFirestore, initializeFirestore} from "firebase/firestore";
import App from "../App";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyDm_MzwSvM_pdicYrUm0oZYvet-kCNvw1E",
    authDomain: "project-9c294.firebaseapp.com",
    projectId: "project-9c294",
    storageBucket: "project-9c294.appspot.com",
    messagingSenderId: "727964910856",
    appId: "1:727964910856:web:d8a4dd96fa2fb9273918bd"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const auth = getAuth (
    app
)

export const BD = initializeFirestore (
    app, {
        experimentalForceLongPolling:true
    }
)


